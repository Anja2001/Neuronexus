"""neuronexux URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.log),
    path('login_post',views.login_post),
    path('admin_home',views.admin_home),
    path('verify_mentor',views.verify_mentor),
    path('approve_mentor/<id>',views.approve_mentor),
    path('reject_mentor/<id>',views.reject_mentor),
    path('view_approved_mentors',views.view_approved_mentors),
    path('view_user',views.view_user),
    path('view_review/<id>',views.view_review),
    path('view_feedback',views.view_feedback),
    path('password',views.password),
    path('password_post',views.password_post),


    path('mentor_home',views.mentor_home),
    path('register',views.register),
    path('register_post',views.register_post),
    path('add_profile',views.add_profile),
    path('edit_profile_post',views.edit_profile_post),
    path('add_schedule',views.add_schedule),
    path('add_schedule_post',views.add_schedule_post),
    path('edit_schedule/<id>',views.edit_schedule),
    path('edit_schedule_post/<id>',views.edit_schedule_post),
    path('view_schedule',views.view_schedule),
    path('remove_schedule/<id>',views.remove_schedule),
    path('mentor_review',views.mentor_review),
    path('mentor_appointment/<id>',views.mentor_appointment),
    path('setasconsulted/<id>',views.setasconsulted),
    path('mentor__payment',views.mentor_payment),
    path('cpassword',views.cpassword),
    path('cpassword_post', views.cpassword_post),

    path('logouts',views.logouts),
    path('forget_pass',views.forget_pass),
    path('forget_pass_post', views.forget_pass_post),
    path('new_pass', views.new_pass),
    path('new_pass_post', views.new_pass_post),


    path('user_register', views.user_register),
    path('user_login', views.user_login),
    path('user_profile', views.user_profile),
    path('user_editprofile', views.user_editprofile),
    path('user_symptoms', views.user_symptoms),
    path('user_view_mentor', views.user_view_mentor),
    path('user_view_scehule', views.user_view_scehule),
    path('user_view_review', views.user_view_review),
    path('user_bookschedule', views.user_bookschedule),
    path('user_makepayment', views.user_makepayment),
    path('user_view_appointment', views.user_view_appointment),
    path('user_send_review', views.user_send_review),
    path('user_send_feedback', views.user_send_feedback),
    path('user_changepass', views.user_changepass),
    path('user_forgot_password', views.user_forgot_password),
    path('user_forgot_email', views.user_forgot_email),
    path('predict', views.predict_disorder),
    path('user_viewchat',views.user_viewchat),
    path('user_sendchat',views.user_sendchat),
    path('user_sendchat_delete',views.user_sendchat_delete),
    path('user_bookschedule2',views.user_bookschedule2)

]
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
