import google.generativeai as genai

# Configure with your API key
genai.configure(api_key="AIzaSyAduEHNgfrIKbihOtLOAUJf9NsoXsw7MW0")  # Replace with your actual key

# Initialize the model (using the correct flash model)
model = genai.GenerativeModel('gemini-1.5-flash')  # ✅ Current fastest model

# Chatbot-style interaction
print("Gemini: Hi! I'm your helpful assistant. Ask me anything about ADHD or other topics.")
print("Type 'quit' to exit.\n")

while True:
    user_input = input("You: ")
    if user_input.lower() == 'quit':
        break

    # Generate response with chatbot personality
    response = model.generate_content(
        f"""Respond to this like a friendly mental health expert:
        User: {user_input}

        Answer conversationally with bullet points when helpful.
        Keep responses under 3 sentences unless detailed explanation is needed.""",
        generation_config={
            "temperature": 0.7,  # More creative
            "max_output_tokens": 500  # Longer responses
        }
    )

    print("\nGemini:", response.text, "\n")