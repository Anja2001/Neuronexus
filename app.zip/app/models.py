from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class mentors(models.Model):
    LOGIN = models.ForeignKey(User,on_delete=models.CASCADE,  default=1)
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone_number=models.CharField(max_length=100)
    qualification=models.CharField(max_length=200)
    experience_proof=models.CharField(max_length=200)
    fee =models.CharField(max_length=200)
    photo=models.CharField(max_length=200)
    status=models.CharField(max_length=200)
    latitude=models.CharField(max_length=200)
    longitude=models.CharField(max_length=200)

class user(models.Model):
    LOGIN = models.ForeignKey(User, on_delete=models.CASCADE, default=1)
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone_number=models.CharField(max_length=100)
    gender=models.CharField(max_length=100)
    age=models.CharField(max_length=100)
    house=models.CharField(max_length=200)
    place=models.CharField(max_length=200)
    pincode=models.CharField(max_length=100)
    photo=models.CharField(max_length=200)


class review(models.Model):
    MENTOR = models.ForeignKey(mentors, on_delete=models.CASCADE)
    USER = models.ForeignKey(user, on_delete=models.CASCADE)
    review=models.CharField(max_length=200)
    date=models.CharField(max_length=200)
    time=models.CharField(max_length=100, default="09:00")



class feedback(models.Model):
    USER = models.ForeignKey(user , on_delete=models.CASCADE)
    feedback1=models.CharField(max_length=200)
    date = models.CharField(max_length=200)
    time = models.CharField(max_length=100, default="09:00")

class schedule(models.Model):
    MENTOR = models.ForeignKey(mentors, on_delete=models.CASCADE)
    date = models.DateField(max_length=200)
    from_time = models.TimeField(max_length=100)
    to_time = models.TimeField(max_length=100)
    Token_number=models.CharField(max_length=100)
    # Token_number_dec=models.CharField(max_length=100)

class appointment(models.Model):
    USER = models.ForeignKey(user , on_delete=models.CASCADE)
    SCHEDULE=models.ForeignKey(schedule, on_delete=models.CASCADE)
    Token=models.CharField(max_length=100)
    date = models.CharField(max_length=200)
    from_time = models.CharField(max_length=100)
    to_time = models.CharField(max_length=100)
    status = models.CharField(max_length=100)


class payment(models.Model):
    APPOINTMENT=models.ForeignKey(appointment, on_delete=models.CASCADE)
    payment=models.CharField(max_length=200)
    date=models.CharField(max_length=100)
    time=models.CharField(max_length=100)


class chatbot(models.Model):
    USER=models.ForeignKey(user, on_delete=models.CASCADE)
    date=models.CharField(max_length=100)
    message=models.TextField(max_length=100)
    type=models.CharField(max_length=100)









