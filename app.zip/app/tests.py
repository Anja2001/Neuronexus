from django.test import TestCase

# Create your tests here.
# models.py
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

# Load your dataset
data = pd.read_csv(r'C:\Users\anjan\PycharmProjects\NEURONEXUS\neuronexux\app\static\Mental disorder symptoms.csv')  # Your dataset
X = data.drop('Disorder', axis=1)
y = data['Disorder']

# Train model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
model = RandomForestClassifier(n_estimators=100)
model.fit(X_train, y_train)

# Save model
joblib.dump(model, r'C:\Users\anjan\PycharmProjects\NEURONEXUS\neuronexux\app\static\mental_health_model.joblib')


# import pandas as pd
# import numpy as np
#
# # Set random seed for reproducibility
# np.random.seed(42)
#
# # Define the number of samples
# n_samples = 500
#
# # Define the column names based on the provided example
# columns = [
#     'Age', 'feeling.nervous', 'panic', 'breathing.rapidly', 'sweating',
#     'trouble.in.concentration', 'having.trouble.in.sleeping', 'having.trouble.with.work',
#     'hopelessness', 'anger', 'over.react', 'change.in.eating', 'suicidal.thought',
#     'feeling.tired', 'close.friend', 'social.media.addiction', 'weight.gain', 'introvert',
#     'popping.up.stressful.memory', 'having.nightmares', 'avoids.people.or.activities',
#     'feeling.negative', 'trouble.concentrating', 'blamming.yourself', 'hallucinations',
#     'repetitive.behaviour', 'seasonally', 'increased.energy', 'Disorder'
# ]
#
# # Initialize an empty list to hold our data
# data = []
#
# # Generate data for 500 individuals
# for i in range(n_samples):
#     # Decide the disorder for this individual first, to influence other traits
#     # Let's aim for a roughly 50/50 split
#     disorder = np.random.choice(['ADHD', 'Non-ADHD'], p=[0.5, 0.5])
#
#     # Generate Age based on disorder
#     if disorder == 'ADHD':
#         age = np.random.randint(12, 45)  # Skew younger
#     else:
#         age = np.random.randint(18, 65)  # Wider range
#
#     # Create a list to hold this individual's data, start with Age
#     row = [age]
#
#     # Generate symptoms (0 or 1). Probabilities differ based on the disorder.
#     for col in columns[1:-1]:  # Skip 'Age' (already done) and 'Disorder' (the target)
#         base_prob = 0.3  # Base probability for any symptom in Non-ADHD
#
#         # Define higher probabilities for specific symptoms in the ADHD group
#         adhd_high_prob_symptoms = [
#             'trouble.in.concentration', 'trouble.concentrating', 'feeling.nervous',
#             'over.react', 'change.in.eating', 'feeling.tired', 'social.media.addiction',
#             'introvert', 'blamming.yourself', 'repetitive.behaviour'
#         ]
#
#         if disorder == 'ADHD':
#             if col in adhd_high_prob_symptoms:
#                 prob = np.random.uniform(0.6, 0.9)  # High probability
#             else:
#                 prob = np.random.uniform(0.4, 0.6)  # Medium probability
#         else:
#             if col in adhd_high_prob_symptoms:
#                 prob = np.random.uniform(0.1, 0.4)  # Low probability
#             else:
#                 prob = base_prob
#
#         # Generate the binary value based on the calculated probability
#         value = np.random.choice([0, 1], p=[1 - prob, prob])
#         row.append(value)
#
#     # Add the target variable
#     row.append(disorder)
#
#     # Append the individual's data to the main list
#     data.append(row)
#
# # Create the DataFrame
# df = pd.DataFrame(data, columns=columns)
#
# # Save to CSV
# df.to_csv('adhd_dataset.csv', index=False)
#
# print("Synthetic dataset of 500 records created successfully!")
# # Let's check the first few rows and the value count for the disorder
# print("\nFirst 5 rows:")
# print(df.head())
# print("\nValue counts for 'Disorder':")
# print(df['Disorder'].value_counts())