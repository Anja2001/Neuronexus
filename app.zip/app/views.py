import base64
import datetime
import os
import random
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import check_password, make_password
from django.contrib.auth.models import Group
from django.core.files.storage import FileSystemStorage
from django.db.models import Max
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from .models import *


projectemail = "userss1520@gmail.com"
projectpassword = "kyol rmrc jotb dszs"

# Create your views here.
def log(request):
    return render(request,'Login.html')

def login_post(request):
    uname=request.POST['email']
    password=request.POST['password']
    data = authenticate(request,username = uname,password = password)
    if data is not None:
        login(request,data)
        if data.is_superuser:
            return redirect('/admin_home')
        if data.groups.filter(name = 'Mentors').exists():
            if mentors.objects.filter(LOGIN=request.user.id, status = "Mentors"):
                request.session['mid'] = mentors.objects.get(LOGIN = request.user.id).id
                return redirect('/mentor_home')
            else:
                return HttpResponse('<script>alert("Pending Approval");window.location="/"</script>')

        if data.groups.filter(name='user').exists():
            request.session['uid'] =user.objects.get(LOGIN = request.user.id).id
            return redirect('/user_home')

    return HttpResponse('<script>alert("Invalid");window.location="/"</script>')


#################################################### ADMIN #######################################################################

@login_required(login_url='/login')
def admin_home(request):
    return render(request,'admin/admin_index.html')

@login_required(login_url='/login')
def verify_mentor(request):
    data = mentors.objects.all()
    return render(request,'admin/View & verified mentors.html',{'data':data})

@login_required(login_url='/login')
def approve_mentor(request,id):
    mentors.objects.filter(id =id).update(status = "Mentors")
    try:
        import smtplib
        s = smtplib.SMTP(host='smtp.gmail.com', port=587)
        s.starttls()
        s.login(projectemail, projectpassword)
        msg = MIMEMultipart()  # create a message.........."
        msg['From'] = projectemail
        msg['To'] = mentors.objects.filter(id=id)[0].email
        msg['Subject'] = "VErfication for Neuronexus Website"
        body = "Your account is verfied"
        msg.attach(MIMEText(body, 'plain'))
        s.send_message(msg)
    except:
        pass
    return HttpResponse("<script>alert('Approved');window.location='/verify_mentor'</script>")

@login_required(login_url='/login')
def reject_mentor(request,id):
    mentors.objects.filter(id =id).update(status = "rejected")
    try:
        import smtplib
        s = smtplib.SMTP(host='smtp.gmail.com', port=587)
        s.starttls()
        s.login(projectemail, projectpassword)
        msg = MIMEMultipart()  # create a message.........."
        msg['From'] = projectemail
        msg['To'] = mentors.objects.filter(id=id)[0].email
        msg['Subject'] = "VErfication for Neuronexus Website"
        body = "Your account is Rejected"
        msg.attach(MIMEText(body, 'plain'))
        s.send_message(msg)
    except:
        pass
    return HttpResponse("<script>alert('Rejected');window.location='/verify_mentor'</script>")

@login_required(login_url='/login')
def view_approved_mentors(request):
    data = mentors.objects.filter(status = "Mentors")
    return render(request,'admin/View verified mentor.html',{'data':data})

@login_required(login_url='/login')
def view_user(request):
    data = user.objects.all()
    return render(request,'admin/View user.html',{'data':data})

@login_required(login_url='/login')
def view_review(request,id):
    data = review.objects.filter(MENTOR_id= id)
    return render(request,'admin/View review.html',{'data':data})

@login_required(login_url='/login')
def view_feedback(request):
    data = feedback.objects.all()
    return render(request,'admin/View feedback.html',{'data':data})

def password(request):
    return render(request,'admin/Change password.html')

def password_post(request):
    oldpass = request.POST['textfield']
    newpass= request.POST['textfield2']
    conpass = request.POST['textfield3']
    data = check_password(oldpass,request.user.password)
    print(data,"opop")
    if data:
        if newpass == conpass:
            user = request.user
            user.set_password(newpass)
            user.save()
            logout(request)
            return HttpResponse('<script>alert("Password changed successfully login again");window.location="/"</script>')
        else:
            return HttpResponse('<script>alert("Password Mismatch");window.location="/password"</script>')
    else:
        return HttpResponse('<script>alert("Password Mismatch");window.location="/password"</script>')


########################################################### MENTOR ################################################################

@login_required(login_url='/login')
def mentor_home(request):
    return render(request,'Mentor/mentor_index.html')


def register(request):
    return render(request,'Mentor/register.html')
def register_post(request):
    mname=request.POST['textfield']
    email = request.POST['textfield2']
    pno = request.POST['textfield3']
    photo = request.FILES['fileField2']
    quli = request.POST['textfield4']
    exp = request.FILES['fileField']
    pas = request.POST['textfield5']
    cpas = request.POST['textfield6']
    fee = request.POST['fee']
    fs = FileSystemStorage()
    photo = fs.save(photo.name,photo)
    exp =fs.save(exp.name,exp)
    z = User.objects.filter(username=email)
    if z.exists():
        return HttpResponse('<script>alert("Already Registered");window.location="/"</script>')
    else:
        if pas == cpas:
            obj = User()
            obj.username = email
            obj.password = make_password(pas)
            obj.save()
            obj.groups.add(Group.objects.get(name = "Mentors"))

            obj1 = mentors()
            obj1.name = mname
            obj1.email=email
            obj1.phone_number=pno
            obj1.photo=fs.url(photo)
            obj1.qualification=quli
            obj1.experience_proof=fs.url(exp)
            obj1.LOGIN = obj
            obj1.status = 'pending'
            obj1.fee = fee
            obj1.latitude = request.POST['latitude']
            obj1.longitude = request.POST['longitude']
            obj1.save()
            return HttpResponse('<script>alert("Successfull");window.location="/"</script>')
        else:
            return HttpResponse('<script>alert("Password must be equal");window.location="/register"</script>')

@login_required(login_url='/login')
def add_profile(request):
    data=mentors.objects.get(LOGIN=request.user.id)
    return render(request,'Mentor/Add profile.html',{'data':data})

@login_required(login_url='/login')
def edit_profile_post(request):

    mname=request.POST['textfield']
    email = request.POST['textfield2']
    pno = request.POST['textfield3']
    quli = request.POST['textfield4']
    fee = request.POST['fee']

    if 'fileField2' in request.FILES:
        fs = FileSystemStorage()
        photo = request.FILES['fileField2']
        photo = fs.save(photo.name,photo)
        mentors.objects.filter(LOGIN=request.user.id).update(photo = fs.url(photo))

    if 'fileField' in request.FILES:
        exp = request.FILES['fileField']
        fs = FileSystemStorage()
        exp =fs.save(exp.name,exp)
        mentors.objects.filter(LOGIN=request.user.id).update(experience_proof = fs.url(exp))

    mentors.objects.filter(LOGIN=request.user.id).update( latitude = request.POST['latitude']
            ,longitude = request.POST['longitude'],
            fee = fee,name = mname,email = email,phone_number = pno,qualification = quli)

    return HttpResponse('<script>alert("updated");window.location="/mentor_home"</script>')



@login_required(login_url='/login')
def add_schedule(request):
    return render(request,'Mentor/Add schedule.html')
def add_schedule_post(request):
    dat=request.POST['textfield']
    frtm=request.POST['textfield2']
    totm=request.POST['textfield3']
    tokn=request.POST['textfield4']
    a=schedule.objects.filter(date=dat,to_time=totm,from_time=frtm)
    if a.exists():
        return HttpResponse('<script>alert("Not Available");window.location="/add_schedule"</script>')
    else:
        obj = schedule()
        obj.date=dat
        obj.from_time=frtm
        obj.to_time=totm
        obj.Token_number=tokn

        obj.MENTOR_id = request.session['mid']
        obj.save()
        return HttpResponse('<script>alert("Added");window.location="/add_schedule"</script>')


@login_required(login_url='/login')
def edit_schedule(request,id):
    data=schedule.objects.get(id = id)
    return render(request,'Mentor/Edit schedule.html',{'data':data})

@login_required(login_url='/login')
def edit_schedule_post(request,id):
    dat = request.POST['textfield']
    frtm = request.POST['textfield2']
    totm = request.POST['textfield3']
    tokn = request.POST['textfield4']

    schedule.objects.filter(id = id).update(date=dat,from_time=frtm,to_time=totm,Token_number=tokn)
    return HttpResponse('<script>alert("updated");window.location="/view_schedule"</script>')

@login_required(login_url='/login')
def remove_schedule(request,id):
    schedule.objects.get(id=id).delete()
    return HttpResponse('<script>alert("Deleted");window.location="/view_schedule"</script>')


@login_required(login_url='/login')
def view_schedule(request):
    data = schedule.objects.filter(MENTOR = request.session['mid'])
    return render(request,'Mentor/View schedule.html',{'data':data})

@login_required(login_url='/login')
def mentor_review(request):
    data = review.objects.filter(MENTOR=request.session['mid'])
    return render(request,'Mentor/view review.html',{'data':data})

@login_required(login_url='/login')
def mentor_appointment(request, id):
    from django.utils import timezone
    from datetime import date, datetime

    today = date.today()
    now = datetime.now().time()
    data2 = []

    data = appointment.objects.filter(SCHEDULE_id=id)

    for d in data:

        # Convert str → time if necessary
        from_time = d.SCHEDULE.from_time
        to_time = d.SCHEDULE.to_time

        if isinstance(from_time, str):
            from_time = datetime.strptime(from_time, "%H:%M:%S").time()
        if isinstance(to_time, str):
            to_time = datetime.strptime(to_time, "%H:%M:%S").time()

        # Check if schedule is ongoing
        if d.SCHEDULE.date == today and from_time <= now <= to_time:
            d.is_active = True


    return render(request, 'Mentor/Appointment.html', {'data': data})


@login_required(login_url='/login')
def setasconsulted(request,id):
    appointment.objects.filter(id=id).update(status="consulted")
    return HttpResponse('<script>alert("Consulted");window.location="/view_schedule"</script>')

@login_required(login_url='/login')
def mentor_payment(request):
    data = payment.objects.filter(APPOINTMENT__SCHEDULE__MENTOR=request.session['mid'])

    return render(request,'Mentor/View payment.html',{'data':data})

def cpassword(request):
    return render(request,'Mentor/Change password.html')

def cpassword_post(request):
    oldpass = request.POST['textfield']
    newpass= request.POST['textfield2']
    conpass = request.POST['textfield3']
    data = check_password(oldpass,request.user.password)
    print(data,"opop")
    if data:
        if newpass == conpass:
            user = request.user
            user.set_password(newpass)
            user.save()
            logout(request)
            return HttpResponse('<script>alert("Password changed successfully login again");window.location="/"</script>')
        else:
            return HttpResponse('<script>alert("Password Mismatch");window.location="/cpassword"</script>')
    else:
        return HttpResponse('<script>alert("Password Mismatch");window.location="/cpassword"</script>')


def logouts(request):
    logout(request)
    return HttpResponse('<script>alert("Logout Sucess");window.location="/"</script>')

def forget_pass(request):
    return render(request,'forgot pass.html')

def forget_pass_post(request):
    email=request.POST['textfield']
    user=User.objects.filter(username=email)
    if user.exists():
        request.session['lid']=user[0].id
        return redirect('/new_pass')
    else:
        return HttpResponse('<script>alert("Invalid");window.location="/forgot_pass"</script>')




def new_pass(request):
    return render(request,'new pass.html')

def new_pass_post(request):
    new_pass=request.POST['textfield']
    confirm_pass=request.POST['textfield2']
    if new_pass==confirm_pass:
        obj=User.objects.get(id=request.session['lid'])
        obj.set_password(new_pass)
        obj.save()
        return HttpResponse('<script>alert("Updated");window.location="/"</script>')
    else:
        return HttpResponse('<script>alert("Password must be equal");window.location="/"</script>')

######################################################### USER #############################################################################################################

def user_register(request):
    name_ = request.POST['name_']
    age_ = request.POST['age_']
    house_ = request.POST['house_']
    place_ = request.POST['place_']
    pin_ = request.POST['pin_']
    email_ = request.POST['email_']
    phone_ = request.POST['phone_']
    pass_ = request.POST['pass_']
    gender = request.POST['gender']

    image_data = request.POST['image']

    if User.objects.filter(username = email_).exists():
        return JsonResponse({"status": "ok"})

    # Decode the base64 image
    image_bytes = base64.b64decode(image_data)

    # Save the image (you might want to use a unique filename)
    upload_folder = r'C:\Users\anjan\PycharmProjects\NEURONEXUS\neuronexux\media\\'
    if not os.path.exists(upload_folder):
        os.makedirs(upload_folder)

    filename = f"{email_}.jpg"  # or use a UUID
    filepath = os.path.join(upload_folder, filename)

    with open(filepath, 'wb') as f:
        f.write(image_bytes)


    obj1 = User()
    obj1.username = email_
    obj1.password = make_password(pass_)
    obj1.save()

    obj1.groups.add(Group.objects.get(name='user'))

    obj = user()
    obj.name = name_
    obj.age = age_
    obj.house = house_
    obj.place = place_
    obj.pincode = pin_
    obj.email = email_
    obj.phone_number = phone_
    obj.gender = gender
    obj.photo = '/media/'+filename


    obj.LOGIN = obj1
    obj.save()

    return JsonResponse({"status":"ok"})

def user_login(request):
    username = request.POST['username']
    password_ = request.POST['password_']
    data = authenticate(request,username = username,password = password_)
    if data is not None:
        login(request, data)
        u=user.objects.get(LOGIN=request.user.id).id

        return JsonResponse({"status":"ok","uid":u,"lid":request.user.id})
    else:
        return JsonResponse({"status": "login failed"})


def user_profile(request):

    data = user.objects.filter(id = request.POST['uid'])[0]

    return JsonResponse({"status": "ok","photo":data.photo,"id":data.id,"name":data.name,"age":data.age,"gender":data.gender,"house":data.house,"place":data.place,"pincode":data.pincode,"email":data.email,"phone_number":data.phone_number})


def user_editprofile(request):
    name_ = request.POST['name_']
    age_ = request.POST['age_']
    house_ = request.POST['house_']
    place_ = request.POST['place_']
    pin_ = request.POST['pin_']
    email_ = request.POST['email_']
    phone_ = request.POST['phone_']
    uid = request.POST['uid']
    gender = request.POST['gender']
    image_data = request.POST['image']
    print(image_data)
    if image_data != "":

        # Decode the base64 image
        image_bytes = base64.b64decode(image_data)

        # Save the image (you might want to use a unique filename)
        upload_folder = r'C:\Users\anjan\PycharmProjects\NEURONEXUS\neuronexux\media\\'
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)

        filename = f"{email_}.jpg"  # or use a UUID
        filepath = os.path.join(upload_folder, filename)

        with open(filepath, 'wb') as f:
            f.write(image_bytes)
        obj = user.objects.get(id=uid)
        obj.photo = '/media/' + filename
        obj.save()

    obj = user.objects.get(id = uid)
    obj.name = name_
    obj.age = age_
    obj.house = house_
    obj.place = place_
    obj.pincode = pin_
    obj.email = email_
    obj.phone_number = phone_

    obj.gender = gender
    obj.save()

    return JsonResponse({"status": "ok"})


def user_symptoms(request):
    return JsonResponse({"status":"ok"})

def user_view_mentor(request):
    data = mentors.objects.filter(status="Mentors")
    message = []
    for i in data:
        message.append({
            'id':i.id,
            'name':i.name,
            'email':i.email,
            'phone':i.phone_number,
            'qualification':i.qualification,
            'experienceproof':i.experience_proof,
            'photo':i.photo,
            'status':i.status,
            'fee':i.fee,
            'location':i.latitude+","+i.longitude
        })

    return JsonResponse({"status":"ok","message":message})




def user_view_scehule(request):
    from django.utils import timezone
    from datetime import date
    from django.db.models import Q
    mid = request.POST['mid']

    today = date.today()
    now = datetime.datetime.now().time()

    data = schedule.objects.filter(
        MENTOR_id=mid
    ).filter(
        Q(date__gt=today) |
        Q(date=today, from_time__gt=now) |
        Q(date=today, from_time__lte=now, to_time__gt=now)
    ).order_by("date", "from_time")

    message = []
    for i in data:
        max_token = appointment.objects.filter(SCHEDULE_id=i.id).aggregate(Max('Token'))['Token__max']
        next_token = 1 if max_token is None else int(max_token) + 1
        if next_token == 1:
            message.append({
                'id': i.id,
                'schedule_date': i.date,
                'schedule_fromtime': i.from_time,
                'schedule_totime': i.to_time,
                'schedule_tokenno': i.Token_number,
                'name': i.MENTOR.name
            })
        else:
            r = int(i.Token_number) - (next_token-1)
            if r > 0:
                message.append({
                    'id': i.id,
                    'schedule_date': i.date,
                    'schedule_fromtime': i.from_time,
                    'schedule_totime': i.to_time,
                    'schedule_tokenno': r,
                    'name': i.MENTOR.name
                })

    return JsonResponse({"status": "ok", "message": message})



def user_view_review(request):
    mid=request.POST['mid']
    data = review.objects.filter(MENTOR_id=mid)
    message = []
    for i in data:
        message.append({
            'id': i.id,
            'Review': i.review,
            'date': i.date,
            'time': i.time,
            'name':i.USER.name


        })
    return JsonResponse({"status": "ok", "message": message})


from django.http import JsonResponse
from .models import appointment
import datetime

def user_bookschedule2(request):
    uid = request.POST['uid']
    sid = request.POST['sid']
    # mode = request.POST['mode']
    today = datetime.datetime.now().date()
    max_token = appointment.objects.filter(SCHEDULE_id=sid).aggregate(Max('Token'))['Token__max']
    next_token = 1 if max_token is None else int(max_token) + 1

    if appointment.objects.filter(USER_id = uid,SCHEDULE_id = sid).exists():
        return JsonResponse({"status":"already"})
    else:
        return JsonResponse({"status":"ok"})

def user_bookschedule(request):
    uid = request.POST['uid']
    sid = request.POST['sid']
    mode = request.POST['mode']
    today = datetime.datetime.now().date()
    max_token = appointment.objects.filter(SCHEDULE_id=sid).aggregate(Max('Token'))['Token__max']
    next_token = 1 if max_token is None else int(max_token) + 1

    if appointment.objects.filter(USER_id = uid,SCHEDULE_id = sid).exists():
        return JsonResponse({"status":"already"})
    obj = appointment()
    obj.USER_id = uid
    obj.SCHEDULE_id = sid
    obj.Token = str(next_token)
    obj.date = today
    obj.from_time = "pending"
    obj.to_time = "pending"
    obj.status = "pending"
    obj.save()


    obj2 = payment()
    obj2.APPOINTMENT_id = obj.id
    obj2.payment = mode
    obj2.date = today
    obj2.time = datetime.datetime.now().time()
    obj2.save()

    return JsonResponse({"status": "ok", "token": obj.Token})


def user_makepayment(request):
    return JsonResponse({"status":"ok"})

def user_view_appointment(request):
    data = appointment.objects.filter(USER__LOGIN=request.POST['id'])
    message = []
    for i in data:
        message.append({
            'id': i.id,
            'Token': i.Token,
            'date': i.SCHEDULE.date,
            'from_time': i.SCHEDULE.from_time,
            'to_time':i.SCHEDULE.to_time,
            'schedule_date': i.SCHEDULE.date,
            'schedule_fromtime':i.SCHEDULE.from_time,
            'schedule_totime': i.SCHEDULE.to_time,
            'schedule_tokenno': i.SCHEDULE.Token_number,
            'mid': i.SCHEDULE.MENTOR_id,
            'name': i.SCHEDULE.MENTOR.name,
            'email': i.SCHEDULE.MENTOR.email,
            'phone': i.SCHEDULE.MENTOR.phone_number,
            'qualification': i.SCHEDULE.MENTOR.qualification,
            'experienceproof': i.SCHEDULE.MENTOR.experience_proof,
            'photo': i.SCHEDULE.MENTOR.photo,
            'status': i.status,
            'location': i.SCHEDULE.MENTOR.latitude + "," + i.SCHEDULE.MENTOR.longitude

        })
    return JsonResponse({"status": "ok", "message": message})


def user_send_review(request):
    review1=request.POST['review']
    uid=request.POST['uid']
    mid = request.POST['mid']
    obj = review()
    obj.USER_id = uid
    obj.MENTOR_id = mid
    obj.review = review1
    obj.date = datetime.datetime.now().date()
    obj.time = datetime.datetime.now().strftime("%H:%M")
    obj.save()

    return JsonResponse({"status":"ok"})

def user_send_feedback(request):
    feedback2=request.POST['feedback']
    uid=request.POST['uid']
    obj= feedback()
    obj.USER_id=uid
    obj.feedback1=feedback2
    obj.date = datetime.datetime.now().date()
    obj.time = datetime.datetime.now().strftime("%H:%M")
    obj.save()

    return JsonResponse({"status":"ok"})

def user_changepass(request):
    changepass = request.POST['changepass']
    print(changepass)
    newpass = request.POST['password']
    print(newpass)
    conpass = request.POST['cpassword']
    print(conpass)
    lid=request.POST['lid']
    print(lid)
    a=User.objects.get(id=lid)
    data = check_password(changepass, a.password)
    if data:
        if newpass == conpass:
            obj = a
            obj.set_password(newpass)
            obj.save()
            logout(request)
            return JsonResponse({"status": "Updated"})
        else:
            return JsonResponse({"Password Mismatch"})
    else:
        return JsonResponse({"status": "Password Mismatch"})



def user_forgot_password(request):
    Password = request.POST['password']
    cpassword = request.POST['cpassword']
    lid = request.POST['lid']
    print(User.objects.get(id=lid),"opop")
    if Password==cpassword:
        obj=User.objects.get(id=lid)
        obj.set_password(Password)
        obj.save()
        return JsonResponse({"status": "ok"})
    else:
        return JsonResponse({"status": "Password Mismatch"})




def user_forgot_email(request):
    email = request.POST['email_']
    user = User.objects.filter(username=email)
    if user.exists():
        otp = str(random.randint(1111,9999))
        import smtplib
        s = smtplib.SMTP(host='smtp.gmail.com', port=587)
        s.starttls()
        s.login(projectemail, projectpassword)
        msg = MIMEMultipart()  # create a message.........."
        msg['From'] = projectemail
        msg['To'] = email
        msg['Subject'] = "Your OTP for Neuronexus Website"
        body = "Your OTP is:- - " + str(otp)
        msg.attach(MIMEText(body, 'plain'))
        s.send_message(msg)

        return JsonResponse({"status":"ok","lid":user[0].id,"otp":otp})
    else:
        return JsonResponse({"status":"Invalid"})


# views.py

import joblib
import numpy as np

def predict_disorder(request):

    # Load trained model
    model = joblib.load(r'C:\Users\anjan\PycharmProjects\NEURONEXUS\neuronexux\app\static\mental_health_model.joblib')

    # Get symptoms from request
    symptoms = request.POST['symptoms']
    symptoms = symptoms.split(',')
    print(symptoms,"pop",len(symptoms))

    if len(symptoms) != 28:  # Verify correct number of features
        return JsonResponse({'error': 'Invalid input length'}, status=400)
    # Predict
    prediction = model.predict([symptoms])[0]
    return JsonResponse({'prediction': prediction})


def user_sendchat(request):
    FROM_id=request.POST['from_id']
    msg=request.POST['message']

    from  datetime import datetime
    c=chatbot()
    c.USER_id=FROM_id
    c.message=msg
    c.date=datetime.now()
    c.type = "user"
    c.save()

    import google.generativeai as genai
    # Configure with your API key
    genai.configure(api_key="AIzaSyAduEHNgfrIKbihOtLOAUJf9NsoXsw7MW0")  # Replace with your actual key
    # Initialize the model (using the correct flash model)
    model = genai.GenerativeModel('gemini-1.5-flash')  # ✅ Current fastest model
    # Generate response with chatbot personality
    response = model.generate_content(
        f"""Respond to this like a friendly mental health expert:
        User: {msg}

        Answer conversationally with bullet points when helpful.
        Keep responses under 3 sentences unless detailed explanation is needed.""",
        generation_config={
            "temperature": 0.7,  # More creative
            "max_output_tokens": 500  # Longer responses
        }
    )
    print("\nGemini:", response.text, "\n")

    from  datetime import datetime
    c = chatbot()
    c.USER_id = FROM_id
    c.message = response.text
    c.date = datetime.now()
    c.type = "chatbot"
    c.save()



    # print(FROM_id, TOID_id,"Lk")




    return JsonResponse({'status':"ok"})

def user_viewchat(request):
    from_id=request.POST['from_id']
    data = chatbot.objects.filter(USER=from_id)
    l = []
    for res in data:
        l.append({'id':res.id,'from':res.USER.id,'msg':res.message,'date':res.date,"type":res.type})
    return JsonResponse({'status':"ok",'data':l})


def user_sendchat_delete(request):
    from_id=request.POST['from_id']
    data = chatbot.objects.filter(USER=from_id).delete()
    return JsonResponse({'status':"ok",'data':1})
